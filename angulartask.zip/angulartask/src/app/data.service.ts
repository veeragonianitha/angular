import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
	info1: string[]=["John mathav","E563","jm@abc.com"]
	info2: string[]=["anitha","E5733","anitha@abc.com"]
	info3: string[]=["Soonu","E89o","soonu@abc.com"]
	
	getInfo1():string[]{
		return this.info1
	}
    
	getInfo2():string[]{
		return this.info2
	}
	
	getInfo3():string[]{
		return this.info3
	}
  constructor() { }
}
