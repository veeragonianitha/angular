import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.css']
})
export class EmailComponent implements OnInit {
   
  emailOne: any;
  emailTwo: any;
  emailThree: any;
  
 // restItems: any;
  restItemsUrl = 'https://reqres.in/api/users/1';
  restItems1Url = 'https://reqres.in/api/users/3';
  restItems2Url = 'https://reqres.in/api/users/10';
  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.getRestItems();
	this.getRestItems1();
	this.getRestItems2();
  }

  // Read all REST Items
  getRestItems(): void {
    this.restItemsServiceGetRestItems(this.restItemsUrl)
      .subscribe((restItems: any) =>{
			if(restItems && restItems.data){
				this.emailOne = restItems.data.email ? restItems.data.email : null ;
				console.log(this.emailOne);
				
			}
		
        }
      )
  }
  
  getRestItems1(): void {
    this.restItemsServiceGetRestItems(this.restItems1Url)
      .subscribe((restItems1: any) =>{
			if(restItems1 && restItems1.data){
				this.emailTwo = restItems1.data.email ? restItems1.data.email : null ;
				
				console.log(this.emailTwo);
				
			}
		
        }
      )
  }
  
  getRestItems2(): void {
    this.restItemsServiceGetRestItems(this.restItems2Url)
      .subscribe((restItems2: any) =>{
			if(restItems2 && restItems2.data){
				this.emailThree = restItems2.data.email ? restItems2.data.email : null ;
				console.log(this.emailThree);
			}
        }
      )
  }
    // Rest Items Service: Read all REST Items
  restItemsServiceGetRestItems(itemUrl: string) {
	  console.log('itemUrl=======');
	  console.log(itemUrl);
    return this.http
      .get<any[]>(itemUrl)
      .pipe(map(data => data));
  }

}
